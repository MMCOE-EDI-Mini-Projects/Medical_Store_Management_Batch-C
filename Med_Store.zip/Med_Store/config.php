<?php
/**
 * Global Configuration Settings
 */

// Application Settings
define('APP_NAME', 'PharmaCare');
// Dynamic APP_URL detection based on current server port
$scheme = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost:8000';
define('APP_URL', $scheme . $host);

// Pharmacy Details (India)
define('PHARMACY_ADDRESS', 'Shop No. 12, MG Road, Connaught Place, New Delhi - 110001');
define('PHARMACY_PHONE', '+91 98765 43210');
define('PHARMACY_EMAIL', 'care@pharmacare.in');
define('PHARMACY_GSTIN', '07AAAAA0000A1Z5');
define('PHARMACY_DL_NO', 'DL-20B/1234/2024');

// Database Settings
define('DB_HOST', 'localhost');
define('DB_NAME', 'pharmacy_db');
define('DB_USER', 'root');
define('DB_PASS', '');

// Stock Settings
define('LOW_STOCK_THRESHOLD', 10);

// Set default timezone
date_default_timezone_set('Asia/Kolkata');

// Error Reporting (Development)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Pagination
define('RECORDS_PER_PAGE', 10);
?>
