# 💊 PharmaCare - Medicine Store Management System

<div align="center">

[![PHP](https://img.shields.io/badge/PHP-8.x-777BB4?style=for-the-badge&logo=php&logoColor=white)](https://www.php.net/)
[![MySQL](https://img.shields.io/badge/MySQL-MariaDB-4479A1?style=for-the-badge&logo=mysql&logoColor=white)](https://www.mysql.com/)
[![HTML5](https://img.shields.io/badge/HTML5-Standard-E34F26?style=for-the-badge&logo=html5&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/HTML)
[![CSS3](https://img.shields.io/badge/CSS3-Modern-1572B6?style=for-the-badge&logo=css3&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/CSS)
[![JavaScript](https://img.shields.io/badge/JavaScript-ES6%2B-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
[![Bootstrap](https://img.shields.io/badge/Bootstrap-5-7952B3?style=for-the-badge&logo=bootstrap&logoColor=white)](https://getbootstrap.com/)
[![Chart.js](https://img.shields.io/badge/Charts-Chart.js-FF6384?style=for-the-badge&logo=chartdotjs&logoColor=white)](https://www.chartjs.org/)

[![GitHub stars](https://img.shields.io/github/stars/jalalakbar47/Medicine-Store?style=for-the-badge&logo=github)](https://github.com/jalalakbar47/Medicine-Store/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/jalalakbar47/Medicine-Store?style=for-the-badge&logo=github)](https://github.com/jalalakbar47/Medicine-Store/network/members)
[![GitHub issues](https://img.shields.io/github/issues/jalalakbar47/Medicine-Store?style=for-the-badge&logo=github)](https://github.com/jalalakbar47/Medicine-Store/issues)
[![Last commit](https://img.shields.io/github/last-commit/jalalakbar47/Medicine-Store?style=for-the-badge&logo=git)](https://github.com/jalalakbar47/Medicine-Store/commits/main)

**A professional, high-performance Pharmacy Management System designed to streamline inventory tracking, sales processing (POS), and business analytics.**

</div>

---

![Main Dashboard](screenshots/dashboard.png)

## 🚀 Key Features

- **Proactive Dashboard:** Real-time stats for revenue, profit, low stock alerts, and upcoming medicine expiries.
- **Dynamic POS System:** Fast billing interface with automated stock deduction and invoice generation.
- **Inventory Management:** Comprehensive tracking of medicines, batches, categories, and expiry dates.
- **Detailed Analytics:** Visual reports for revenue, profit, and top-selling medicines using Chart.js.
- **User Management & RBAC:** Role-based access control for Admins and Staff members.
- **Secure Architecture:** Built using PDO prepared statements to prevent SQL Injection and CSRF protection for all forms.
- **Premium UI:** Modern, responsive design featuring glassmorphism elements and smooth animations.

## 🛠️ Technology Stack

- **Backend:** PHP 8.x (Core)
- **Database:** MySQL (MariaDB)
- **Frontend:** HTML5, CSS3 (Vanilla + Modern Design System), Bootstrap 5
- **Charts:** Chart.js
- **Icons:** FontAwesome 6

## 📦 Installation Guide

To get this project running locally on your machine (using XAMPP):

1. **Clone the Repository:**
   ```bash
   git clone https://github.com/jalalakbar47/Medicine-Store.git
   ```

2. **Setup Database:**
   - Open **phpMyAdmin**.
   - Create a new database named `pharmacy_db`.
   - Import the `database.sql` file provided in the root directory.

3. **Configure the App:**
   - Open `config.php`.
   - Update `DB_USER`, `DB_PASS`, and `APP_URL` if they differ from your local setup.

4. **Run the Project:**
   - Move the project folder to `C:\xampp\htdocs\`.
   - Access the system via `http://localhost/Medicine-Store`.

## 🔐 Login Credentials

| Role | Username | Password |
| :--- | :--- | :--- |
| **Admin** | `admin` | `admin123` |

## 📸 Visuals & Gallery

Place your screenshots in the `/screenshots` folder using the exact names below:

### Login Interface
![Login Page](screenshots/login_page.png)

### Proactive Dashboard
![Dashboard](screenshots/dashboard.png)

### Point of Sale (POS)
![POS System](screenshots/pos_system.png)

### Inventory Management
![Inventory](screenshots/inventory_management.png)

### Analytics & Reports
![Analytics](screenshots/analytics_reports.png)

### User & Staff Management
![User Management](screenshots/user_management.png)

## 🤝 Contributing

Contributions are welcome! Feel free to open an issue or submit a pull request.

## 📄 License
This project is open-source and available under the [MIT License](LICENSE).
## 👨‍💻 Author & Dedication
Created with ❤️ by [jalalakbar47](https://github.com/jalalakbar47)
> **Dedicated To My ❤️ J/S — My Inspiration.**
